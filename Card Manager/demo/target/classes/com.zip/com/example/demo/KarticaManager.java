package com.example.demo;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class KarticaManager {

    private final KarticaRepository kartice = new KarticaRepository();

    public void dodajKarticu(Kartica kartica) {
        if (pronadiPoId(kartica.getIdBroj()) != null) {
            throw new IllegalArgumentException("Kartica s tim ID-em već postoji.");
        }
        kartice.add(kartica);
    }

    public void urediKarticu(int idBroj, String ime, String odjel,
                             LocalDate izdavanje, LocalDate istek, Kartica.Status status) {
        Kartica k = pronadiPoId(idBroj);
        if (k == null) throw new IllegalArgumentException("Kartica ne postoji.");
        k.setIme(ime);
        k.setOdjel(odjel);
        k.setDatumIzdavanja(izdavanje);
        k.setDatumIsteka(istek);
        k.setStatus(status);
    }

    public boolean obrisiKarticu(int idBroj) {
        return kartice.removeIf(k -> k.getIdBroj() == idBroj);
    }

    public List<Kartica> dohvatiSve() {
        return new ArrayList<>(kartice);
    }

    public boolean jeBlokirana(int idBroj) {
        return dohvati(idBroj).getStatus() == Kartica.Status.BLOKIRANA;
    }

    public boolean jeIstekla(int idBroj) {
        return dohvati(idBroj).getDatumIsteka().isBefore(LocalDate.now());
    }

    public boolean jeAktivna(int idBroj) {
        return !jeBlokirana(idBroj) && !jeIstekla(idBroj);
    }


    private Kartica pronadiPoId(int idBroj) {
        for (Kartica k : kartice) {
            if (k.getIdBroj() == idBroj) return k;
        }
        return null;
    }

    private Kartica dohvati(int idBroj) {
        Kartica k = pronadiPoId(idBroj);
        if (k == null) throw new IllegalArgumentException("Kartica ne postoji.");
        return k;
    }
}