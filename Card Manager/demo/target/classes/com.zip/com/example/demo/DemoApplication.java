package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import java.time.LocalDate;

@SpringBootApplication
public class DemoApplication {

	public static void main(String[] args) {

		// 1. Kreiranje managera
		KarticaManager manager = new KarticaManager();

		// 2. Kreiranje kartica
		Kartica k1 = new Kartica(
				"Ivan Horvat",
				101,
				"IT",
				LocalDate.of(2025, 1, 10),
				LocalDate.of(2027, 1, 10),
				Kartica.Status.AKTIVNA
		);

		Kartica k2 = new Kartica(
				"Ana Anić",
				102,
				"Financije",
				LocalDate.of(2024, 1, 10),
				LocalDate.of(2025, 1, 10),
				Kartica.Status.AKTIVNA
		);

		Kartica k3 = new Kartica(
				"Marko Marić",
				103,
				"Marketing",
				LocalDate.of(2025, 3, 15),
				LocalDate.of(2027, 3, 15),
				Kartica.Status.BLOKIRANA
		);

		// 3. Dodavanje kartica
		manager.dodajKarticu(k1);
		manager.dodajKarticu(k2);
		manager.dodajKarticu(k3);

		System.out.println("=== SVE KARTICE ===");

		for (Kartica k : manager.dohvatiSve()) {
			ispisiKarticu(k);
		}

		// 4. Provjera statusa kartica
		System.out.println("\n=== PROVJERA KARTICA ===");

		System.out.println("Kartica 101 je blokirana: "
				+ manager.jeBlokirana(101));

		System.out.println("Kartica 102 je istekla: "
				+ manager.jeIstekla(102));

		System.out.println("Kartica 103 je aktivna: "
				+ manager.jeAktivna(103));

		System.out.println("Kartica 101 je aktivna: "
				+ manager.jeAktivna(101));

		// 5. Uređivanje kartice
		System.out.println("\n=== UREĐIVANJE KARTICE ===");

		manager.urediKarticu(
				103,
				"Marko Marić",
				"IT",
				LocalDate.of(2025, 3, 15),
				LocalDate.of(2028, 3, 15),
				Kartica.Status.AKTIVNA
		);

		System.out.println("Kartica nakon uređivanja:");
		ispisiKarticu(k3);

		System.out.println("Kartica 103 je aktivna: "
				+ manager.jeAktivna(103));

		// 6. Brisanje kartice
		System.out.println("\n=== BRISANJE KARTICE ===");

		boolean obrisana = manager.obrisiKarticu(102);

		System.out.println("Kartica 102 obrisana: " + obrisana);

		// 7. Prikaz preostalih kartica
		System.out.println("\n=== PREOSTALE KARTICE ===");

		for (Kartica k : manager.dohvatiSve()) {
			ispisiKarticu(k);
		}

		// 8. Testiranje duplikata
		System.out.println("\n=== TEST DUPLIKATA ===");

		try {
			manager.dodajKarticu(k1);
		} catch (IllegalArgumentException e) {
			System.out.println("Greška: " + e.getMessage());
		}

		// 9. Testiranje nepostojeće kartice
		System.out.println("\n=== TEST NEPOSTOJEĆE KARTICE ===");

		try {
			manager.jeAktivna(999);
		} catch (IllegalArgumentException e) {
			System.out.println("Greška: " + e.getMessage());
		}
	}

	// Pomoćna metoda za ispis kartice
	public static void ispisiKarticu(Kartica k) {
		System.out.println("-------------------------");
		System.out.println("Ime: " + k.getIme());
		System.out.println("ID broj: " + k.getIdBroj());
		System.out.println("Odjel: " + k.getOdjel());
		System.out.println("Datum izdavanja: " + k.getDatumIzdavanja());
		System.out.println("Datum isteka: " + k.getDatumIsteka());
		System.out.println("Status: " + k.getStatus());
	}
}